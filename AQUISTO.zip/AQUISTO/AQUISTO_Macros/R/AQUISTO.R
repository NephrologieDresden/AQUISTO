##setting basic directories

dirfiji<-"T:/mk3-L02/+Friederike/Fiji.app/ImageJ-win64.exe"
dirdata<-"Z:/"
dirsource<-paste0(dirdata, "AQUISTO_Macros/")
.libPaths(paste0(dirsource, "/R/Packages"))

##libraries and packages

require(ggplot2)
require(reshape2)

library(ggplot2)
library(reshape2)

source(paste0(dirsource, "R/Total.R"))

