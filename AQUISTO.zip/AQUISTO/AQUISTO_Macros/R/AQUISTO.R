## Automatic quantification of whole histological sections AQUISTO
#   programmed by Friederike Kessel (2019) in the Department of Internal Medicine III,
#   Workgroup of Experimental Nephrology AG Hugo
#   Carl Gustav Carus University Dresden

#   cite the following publication for reference
#   "New automatic quantification method of immunofluorescence and histochemistry in whole histological sections."
#   doi: 10.1016/j.cellsig.2019.05.020. [Epub ahead of print], Cellular Signaling 2019

##setting basic directories

dirfiji<-"T:/mk3-L02/+Friederike/Fiji.app/ImageJ-win64.exe"
#on the workstation:
#dirfiji<-"C:/Users/MTZImaging/Desktop/Fiji.app/ImageJ-win64.exe"

dirdata<-"Z:/"
dirsource<-paste0(dirdata, "AQUISTO_Macros/")
.libPaths(paste0(dirsource, "/R/Packages"))

##libraries and packages

#require(ggplot2)
#require(reshape2)

#install.packages("rlang", lib = paste0(dirsource, "/R/Packages"))
library(ggplot2)
library(reshape2)

source(paste0(dirsource, "R/Total.R"))

